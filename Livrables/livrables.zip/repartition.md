# Répartition du travail

## Partie 1

Maxime : 2.25/6 (Doc technique en html, doc utilisateur en MD, doc utilisateur en HTML en commun avec les autres)
Cyprien : 1.25/6 (src1.c, doc utilisateur en HTML en commun avec les autres)
Igor : 1.25/6 (src3.c, doc utilisateur en HTML en commun avec les autres)
Raphaël : 1.25/6 (src2.c, doc utilisateur en HTML en commun avec les autres)

## Partie 2

Maxime : 
Cyprien : 
Igor : 
Raphaël : 

